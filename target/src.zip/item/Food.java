package item;

public class Food {
	String name;
	int freshness;
	int price;
	
	public Food(String name, int f, int p) 
	{
		this.name = name;
		freshness = f;
		price = p;
	}
	public int getPrice()
	{
		return price + freshness;
	}
	public int getFresh() { return this.freshness;}
}
