package human;

import item.Food;

public class Shoper {
	int defLv;
	int cash = 0;
	
	public Shoper(int defLv)
	{
		this.defLv = defLv;
	}
	public int def(Food target)
	{
		return defLv *target.getFresh();
	}
	public void addCash(int c)
	{
		cash+=c;
	}
}
