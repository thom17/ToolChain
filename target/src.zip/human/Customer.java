package human;

import item.Food;

public class Customer {
	int speakLv;
	int cash;
	int pos= 0;
	Food foodList[] = new Food[5];
	public Customer(int lv, int cash)
	{
		this.speakLv = lv;
		this.cash = cash;
	}
	
	public boolean bargaining( Shoper shoper , Food target)
	{
		if( shoper.def(target) < speakLv) return true;
		else return false;
			
	}
	public void getFood(Food food, int count)
	{
		foodList[pos++] = food;
		cash -= count;
		
	}
	
}
