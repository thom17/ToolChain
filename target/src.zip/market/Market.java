package market;

import human.Customer;
import human.Shoper;
import item.Food;

public class Market {
	Shoper shoper;
	Food foodList[];
	int pos = 0;
	public Market(Shoper shoper, Food foodList[])
	{
		this.shoper = shoper;
		this.foodList = foodList;
	}
	public Food choice(Customer customer)
	{
		return foodList[pos];
	}
	public int getPrice(Customer customer, Food food)
	{
		int price = food.getPrice();
		if (customer.bargaining(shoper, food)) price -= food.getFresh(); 
		return price;
	}
	public boolean trade(Customer customer, Food food, int c)
	{
		pos++;
		customer.getFood(food, c);
		shoper.addCash(c);
		return true;
	}
	public static void main(String args[])
	{
		Food food1 = new Food("����", 3, 50);
		Food food2 = new Food("���", 5, 55);
		Food food3 = new Food("��", 2, 35);
		Food flist[] = {food1, food2, food3};
		Shoper shoper = new Shoper(15);
		Customer ct = new Customer(10, 100);
		Market mk = new Market(shoper, flist);
		Food f = mk.choice(ct);
		int m = mk.getPrice(ct, f);
		mk.trade(ct, f, m);
		
		
	}
	
}
