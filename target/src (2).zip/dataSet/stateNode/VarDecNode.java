package dataSet.stateNode;

public class VarDecNode extends StateNode
{
	String type;
	
	public void setType(String type)
	{
		this.type= type;
	}
	
}
