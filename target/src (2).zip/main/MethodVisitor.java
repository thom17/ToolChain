package main;

import dataSet.Function;

public class MethodVisitor extends Test_Visitor
{

	public MethodVisitor(Function fun) {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
