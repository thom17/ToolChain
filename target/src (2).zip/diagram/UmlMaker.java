package diagramMaker;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public abstract class UmlMaker 
{
	/*
	StringBuilder script = null;
	
	public void makeFile(String name) throws IOException
	{
		File file = new File(name);
		FileWriter fw = new FileWriter(file, false);
		fw.write(script.toString());
		fw.close();	
	}
	 */
}
