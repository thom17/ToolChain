package diagram;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.eclipse.jdt.core.dom.Expression;

import dataSet.Class;
import dataSet.DataList;
import dataSet.Function;
import dataSet.Member;
import dataSet.stateNode.StateNode;
public class ForQuiz3 
{
	static String skipValue[] = {};
	static String skipClass[] = {};
	static int funNum=0;
	static ArrayList<StateNode> nodelist;
//	static int memNum=0;
//	static long nodeNum=0;
	
	public static void main(String args[]) throws IOException, InterruptedException
	{
		Process p = Runtime.getRuntime().exec("java -jar libs/plantuml.jar result/quiz3.txt");
		p.waitFor();
		System.out.println("quiz draw done : quiz3.svg");
	}
	public static void main(DataList datalist) throws IOException, InterruptedException
	{
 		nodelist = new ArrayList<StateNode>();
		String script = makeScript(datalist);
		makeFile(script, "result/quiz3.txt");
		//Process p = Runtime.getRuntime().exec("java -jar libs/plantuml.jar -tsvg result/quiz.txt");
		Process p = Runtime.getRuntime().exec("java -jar libs/plantuml.jar -tsvg result/quiz3.txt");
		p.waitFor();
		System.out.println("quiz draw done : quiz3.svg");
	}
 	public static void makeFile(String script, String src) throws IOException
	{
		File file = new File(src);
		FileWriter fw = new FileWriter(file, false);
		fw.write(script);
		fw.close();	
	}
 	private static boolean checkSkipList(String target , String checkList[])
 	{
 		for( String check : checkList)
 		{
 			if( target.equals(check) ) return true;
 		}
 		
 		return false;
 	}
	private static String makeScript(DataList datalist) 
	{
		StringBuilder sb = new StringBuilder("@startuml\n");
		ArrayList<Class> classList = datalist.getClassList();
		
		for(Class target : classList)
		{
			String targetName = target.getName();
			if( checkSkipList(target.getName(), skipClass)) continue;
			
			sb.append("state " + '"' + targetName + '"' + " as cl"+target.hashCode() + " {\n");
			makeMemberInfo(target, sb);
			makeFunctionInfo(target, sb);
			sb.append("}\n");
		}
		sb.append("@enduml");
		return sb.toString();
	}
	private static void makeMemberInfo(Class target, StringBuilder sb)
	{
		ArrayList<Member> memberList = target.getHasList().getMemberList();
		int hash = memberList.hashCode();
		String hashCode="";
		if( hash < 0)
		{
			hash = hash * -1;
			hashCode = "_";
		}
		hashCode += hash;
		sb.append("state "+'"' + "memberList" + '"' + " as has"+ hash+" #green{\n");
		for(Member var : memberList)
		{
			String typeName = var.getTypeName();
			String name = var.getName();
		
			if( checkSkipList(name, skipValue)) continue;
		
			String str = '"'+typeName + " " +name+'"';
			String key = "var"+var.hashCode();
			sb.append("state " + str + " as " + key+":"+var.getImageList().toString()+"\n");			
		}
		sb.append("}\n");
	}
	private static void makeFunctionInfo(Class target, StringBuilder sb) 
	{
		ArrayList<Function> functionList = target.getHasList().getFunctionList();
		
		for(Function fun : functionList)
		{
			funNum =0;
			String funName = fun.getName();
			String typeName = fun.getTypeName();
			sb.append("state " + '"' +typeName+" " +funName+ '"' + " as fun"+target.hashCode() + "{\n");
			makeExpInfo(fun.getHeadNode(), sb);
			sb.append("}\n");
		}
		
	}
	private static void makeExpInfo(StateNode node, StringBuilder sb) 
	{
		if(nodelist.contains(node))
			return;
		nodelist.add(node);
		
		String code = node.getCode();
		//if(code.contains('('));
		String check = node.getCondition();
		String before = "node"+node.hashCode();
		sb.append("state " + '"' + "node_"+ funNum++ + '"' + " as node"+node.hashCode() +":"+code+"\n");
		StateNode thenNode = node.getThen();
		if( thenNode != null)
		{
			if(check.equals("true")) check = "";
			else check = ":"+check;
			
			sb.append(before + "--> "+"node"+thenNode.hashCode()+" "+check+"\n");
			makeExpInfo(thenNode,sb);
			
			StateNode elseNode = node.getElse();
			if(elseNode != null)
			{
				sb.append(before + "--> "+ "node"+elseNode.hashCode() +" : else"+"\n");
				makeExpInfo(elseNode, sb);
			}
		}
	}
}
